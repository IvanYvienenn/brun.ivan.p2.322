
package model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import repository.CSVSerializable;


public class BestiarioUpsideDown<T extends CSVSerializable> {
    
    private List<T> criaturas= new ArrayList<>();

    
    public void agregar(T criatura){
        Objects.requireNonNull(criatura, "nulo");
        criaturas.add(criatura);
    }
    
    public T obtenerCriaturaPorIndice(int indice) {
        validarIndice(indice);
        return criaturas.get(indice);
    }
    public void eliminarCriatura(int indice) {
        validarIndice(indice);
        criaturas.remove(indice);
    }
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> listaFiltrada = new ArrayList<>();
        for (T criatura : criaturas) {
            if (criterio.test(criatura)) {
                listaFiltrada.add(criatura);
            }
        }
        return listaFiltrada;
    }
    public void ordenar(Comparator<T> criterio) {
        Collections.sort(criaturas, criterio);

    }

    public void ordenar() {
        this.ordenar(null);

    }
    public void guardarEnArchivo(String path) throws FileNotFoundException, IOException {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))) {
            serializador.writeObject(criaturas);
        } 
    }
    public void cargarDesdeArchivo(String path) throws FileNotFoundException, IOException, ClassNotFoundException {

        try (ObjectInputStream deserializador = new ObjectInputStream(new FileInputStream(path))) {
            criaturas = (List<T>) deserializador.readObject();
        } 

    }
    public void guardarEnCSV(String path) throws IOException {
        try (BufferedWriter escritorArchivos = new BufferedWriter(new FileWriter(path))) {
            for (T c : criaturas) {
                escritorArchivos.write(c.toCSV());
                escritorArchivos.newLine();
            }

        } 
    }
    public void cargarDesdeCSV(String path, Function<String, T> tranformador) throws FileNotFoundException, IOException {
        String linea;
        try (BufferedReader lectorArchivos = new BufferedReader(new FileReader(path))) {
            while ((linea = lectorArchivos.readLine()) != null) {
                T criatura = tranformador.apply(linea);
                criaturas.add(criatura);
            }
        } 
    }
    public void paraCadaElemento(Consumer<T> accion) {
        for (T criatura : criaturas) {
            accion.accept(criatura);
        }
    }
    private void validarIndice(int indice) {
        if (indice < 0 || indice >= criaturas.size()) {
            throw new IndexOutOfBoundsException();
        }
    }
}
