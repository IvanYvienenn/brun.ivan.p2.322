
package model;

import java.io.Serializable;
import repository.CSVSerializable;


public class Criatura implements Comparable<Criatura>, CSVSerializable, Serializable{
    private int id;
    private String nombre;
    private String origen;
    private TipoCriatura tipoCriatura;

    public Criatura(int id, String nombre, String origen, TipoCriatura tipoCriatura) {
        this.id = id;
        this.nombre = nombre;
        this.origen = origen;
        this.tipoCriatura = tipoCriatura;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getOrigen() {
        return origen;
    }

    public TipoCriatura getTipoCriatura() {
        return tipoCriatura;
    }

    @Override
    public String toString() {
        return "Criatura{" + "id=" + id + ", nombre=" + nombre + ", origen=" + origen + ", tipoCriatura=" + tipoCriatura + '}';
    }

    @Override
    public int compareTo(Criatura c) {
        return Integer.compare(this.id, c.id);
    }

    @Override
    public String toCSV() {
        return id + "," + nombre + "," + origen + "," + tipoCriatura;
    }
    
    public static Criatura fromCSV(String linea){
        String [] atributos = linea.split(",");
        return new Criatura(Integer.parseInt(atributos[0]), 
                            atributos[1], 
                            atributos[2], 
                            TipoCriatura.valueOf(atributos[3]));
    }
    
}
