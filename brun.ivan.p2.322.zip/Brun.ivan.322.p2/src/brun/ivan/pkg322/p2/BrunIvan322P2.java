/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package brun.ivan.pkg322.p2;

import config.RutaArchivos;
import java.io.IOException;
import model.BestiarioUpsideDown;
import model.Criatura;
import model.TipoCriatura;

/**
 *
 * @author Ivan
 */
public class BrunIvan322P2 {

    public static void main(String[] args) {
        try {
            BestiarioUpsideDown<Criatura> bestiario = new BestiarioUpsideDown<>();
            bestiario.agregar(new Criatura(1, "Demogorgon", "Upside Down", TipoCriatura.DEMOGORGON));
            bestiario.agregar(new Criatura(2, "Demodog Juvenil", "Bosque de Hawkins", TipoCriatura.DEMODOG));
            bestiario.agregar(new Criatura(3, "Shadow Tendril", "Dimensión Principal", TipoCriatura.SHADOW_MONSTER));
            bestiario.agregar(new Criatura(4, "Mind Flayer Spawn", "Upside Down", TipoCriatura.MIND_FLAYER_MINION));
            bestiario.agregar(new Criatura(5, "Murciélago del Upside Down", "Cueva Oscura", TipoCriatura.MURCIELAGO));
            System.out.println("Criaturas:");
            bestiario.paraCadaElemento(c -> System.out.println(c));
            System.out.println("\nCriaturas tipo DEMODOG:");
            bestiario.filtrar(c -> c.getTipoCriatura() == TipoCriatura.DEMODOG)
                    .forEach(System.out::println);
            System.out.println("\nCriaturas que contienen 'shadow':");
            bestiario.filtrar(c -> c.getNombre().contains("Shadow"))
                    .forEach(System.out::println);
            System.out.println("\nCriaturas ordenadas por ID:");
            bestiario.ordenar();
            bestiario.paraCadaElemento(System.out::println);
            System.out.println("\nCriaturas ordenadas por nombre:");
            bestiario.ordenar((c1, c2) -> c1.getNombre().compareTo(c2.getNombre()));
            bestiario.guardarEnArchivo(RutaArchivos.getRutaBINString());
            BestiarioUpsideDown<Criatura> cargado = new BestiarioUpsideDown<>();
            cargado.cargarDesdeArchivo(RutaArchivos.getRutaBINString());
            System.out.println("\nCriaturas cargadas desde archivo binario:");
            cargado.paraCadaElemento(System.out::println);
            System.out.println("---------------------------------------------------------");
            bestiario.guardarEnCSV(RutaArchivos.getRutaCSVString());
            cargado.cargarDesdeCSV(RutaArchivos.getRutaCSVString(), c -> Criatura.fromCSV(c));
            System.out.println("\nCriaturas cargadas desde archivo CSV:");
            cargado.paraCadaElemento(System.out::println);
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

}
